# Operations

All commands run from the package root. Use `run_blast_pit.bat` on Windows.

## Train

Use the README command. A distinct experiment directory is created under `artifacts\v35\<experiment-id>`.

## Continue

```bat
run_blast_pit.bat continue --experiment-id v35-production-001 --resume artifacts\v35\v35-production-001\evolution_state_v35.npz --additional-generations 20 --seed 20260711 --workers 8 --engine python --inference batch
```

Seed and scientific engine must match the checkpoint. Worker count may change.

## Inspect and visualize

```bat
run_blast_pit.bat inspect --checkpoint artifacts\v35\v35-production-001\evolution_state_v35.npz
run_blast_pit.bat visualize --checkpoint artifacts\v35\v35-production-001\validation_hof_v35.npz --seed 20260711
```

Controls: Esc quit; Space pause; period single-step; brackets speed; R deterministic restart; H sensor HUD.

## Audit and release

```bat
run_blast_pit.bat audit --experiment-id v35-production-001 --resume artifacts\v35\v35-production-001\evolution_state_v35.npz --seed 20260711 --workers 8 --engine python --inference batch
```

Audit is one-shot for a provenance identity and idempotent only when that identity is unchanged. If interruption occurs after the release checkpoint but before manifest publication, rerun the identical audit command; v35 deterministically rebuilds the missing manifest.

Exit codes: 0 success, 3 validation/provenance error, 5 interrupted with the last committed generation resumable.
