# Specialist Review Record

The v35 package was reviewed in parallel across architecture/performance, workflow/governance/security, and UI/testing/documentation disciplines.

Implemented high-priority findings include centralized fitness semantics, accumulated offspring opportunity time, explicit suite weights, honest development-confirmation terminology, incremental resource indexing, version separation from v34, release-manifest crash recovery, bounded/offline execution, expanded Windows operations, migration guidance, and deterministic/lifecycle tests.

Recommended future work retained as explicit backlog: durable experiment-wide lock with owner-dead recovery; multi-file commit journal; cryptographically signed approvals when external authority is required; offline `verify` and explicit `release` commands; complete structure-of-arrays compiled frame engine; adaptive mutation state persisted in checkpoints; two-stage candidate evaluation; richer accessible visualization; Windows reparse-point enforcement; fault-injection and concurrency soak suites.

These backlog items are not claimed as implemented in v35. The included security and governance documentation states the current boundaries directly.
