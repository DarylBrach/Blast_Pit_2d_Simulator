# Windows Installation

Target: `E:\Code\Python\VirtualEnvironments\Blast_Pit\2d_Simulator`.

Extract the ZIP so `README.md` and `run_blast_pit.bat` are directly inside that directory. Open Command Prompt:

```bat
cd /d E:\Code\Python\VirtualEnvironments\Blast_Pit\2d_Simulator
py -3.11 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
run_tests.bat
```

The launchers resolve paths relative to their own location, so they also work when invoked from another current directory. Do not include `.venv` in backups of experiment evidence. Keep artifact storage on the same local volume to preserve atomic replacement semantics.
