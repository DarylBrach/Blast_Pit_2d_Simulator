# Testing

Run `run_tests.bat`. The included suite checks configuration policy, finite bounded fitness, offspring exposure accounting, suite isolation, deterministic seed derivation, spatial index churn, trial determinism, CLI compilation, and package inventory.

Release qualification should additionally compare workers 1 and N, uninterrupted versus resumed evolution, repeated golden seeds, corrupt/oversized NPZ rejection, audit idempotency, manifest recovery, Windows spawn, headless visualization, and a 20-generation soak. Benchmark before selecting worker count because process startup can dominate short trials.
