# Final QA

- Extract into a clean Python 3.11 environment, including a path containing spaces.
- Install `requirements.txt` and run all tests.
- Run the same golden trial twice and compare final-state hashes.
- Compare workers 1 and 2/4 for ordered semantic equivalence.
- Compare uninterrupted and train/continue runs.
- Exercise interrupt recovery and audit/manifest recovery on a disposable experiment.
- Reject corrupted checkpoints, mismatched approval/config/seed/engine, and unsafe experiment IDs.
- Execute README and Operations commands verbatim on Windows.
- Confirm the source contains no network or subprocess calls.
- Record benchmark, ZIP SHA-256, and release inventory.
- Exclude `.venv`, caches, temporary artifacts, and real audit outputs from distribution.
