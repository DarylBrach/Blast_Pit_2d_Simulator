# Evidence and Governance

The experiment binds configuration, approval digest, experiment ID, master seed, engine fingerprint, genome hashes, ordered trial seeds, and previous generation hash. Worker count is operational metadata and does not alter scientific semantics. Only the parent writes evidence.

The local approval record expresses operator authorization but is not cryptographically signed. Audit is sealed by lifecycle controls, not secrecy. Release evidence should be retained with the complete experiment directory. Any manual artifact edit invalidates its hash or semantic checks.
