# Workflow State Machine

Observable lifecycle: `NEW -> APPROVED -> TRAINING -> TRAINING_COMMITTED -> AUDITED -> RELEASED`.

The approval record is checked before mutation. Training and continuation never invoke audit. The parent process commits complete generations. Audit evidence is written atomically and validated before release. RELEASED is terminal for training and continuation. Inspect and visualize are read-only.

On interruption during evaluation, no partial generation is committed. On interruption after release-state persistence but before manifest publication, an identical audit invocation reconstructs the manifest from validated artifacts.
