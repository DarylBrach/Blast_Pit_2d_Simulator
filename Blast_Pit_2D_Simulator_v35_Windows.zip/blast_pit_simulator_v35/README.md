# Blast_Pit Creature Simulator v35

BLUF: v35 is a deterministic, governed evolutionary simulator for Windows/Python 3.11. It corrects lineage and late-birth fitness, prevents trial-count changes from silently reweighting standard versus challenge suites, maintains static resource indexes incrementally, preserves parent-only evidence writes, and makes interrupted release-manifest creation recoverable.

## Install at the requested location

```bat
cd /d E:\Code\Python\VirtualEnvironments\Blast_Pit\2d_Simulator
py -3.11 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Smoke test

```bat
run_tests.bat
```

## Train

```bat
run_blast_pit.bat train --experiment-id v35-production-001 --generations 50 --trials 5 --challenge-trials 2 --validation-trials 7 --audit-trials 11 --max-frames 6000 --seed 20260711 --workers 8 --engine python --inference batch
```

Continue, inspect, visualize, and audit examples are in [docs/OPERATIONS.md](docs/OPERATIONS.md). Audit is explicit and is never run by training. The repeated fixed-seed suite is development confirmation because it selects the Hall of Fame; it is not represented as an untouched validation set. Audit seeds are workflow holdouts, not secrets.

## Important compatibility rule

v34 checkpoints cannot be resumed by v35. The fitness, metric, engine, and evidence contracts changed. Finish existing v34 experiments with v34 or begin a new v35 experiment. See [docs/MIGRATION_V34_TO_V35.md](docs/MIGRATION_V34_TO_V35.md).

This local simulator performs no network or subprocess operations. It is not an OS sandbox and runs with the invoking user's filesystem privileges.
