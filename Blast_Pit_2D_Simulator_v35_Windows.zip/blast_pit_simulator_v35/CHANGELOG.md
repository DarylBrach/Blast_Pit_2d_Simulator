# Changelog

## v35

- Centralized the fitness policy used by execution and evidence validation.
- Corrected offspring survival using accumulated possible post-birth frames.
- Added founder, lineage, population-integral, and terminal-population survival.
- Added hydration maintenance and severe-thirst exposure metrics.
- Replaced hard count caps with smooth saturating resource/reproduction scores.
- Replaced distance-reward efficiency with useful outcome per energy.
- Added explicit 70/30 standard/challenge suite aggregation.
- Maintained static resource indexes incrementally; only moving creatures rebuild.
- Added recoverable release-manifest publication.
- Versioned artifacts, approvals, checkpoints, and documentation as v35.
