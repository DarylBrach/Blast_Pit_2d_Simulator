from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).parent
SPEC = importlib.util.spec_from_file_location("simulator_v35", ROOT / "tmp_2d_simulator_v35.py")
assert SPEC and SPEC.loader
sim = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = sim
SPEC.loader.exec_module(sim)


def metric(**updates):
    base = sim.LineageMetrics().raw()
    base.update(
        founder_survival_frames=100,
        lineage_alive_frames=100,
        hydrated_alive_frames=80,
        offspring_born=1,
        offspring_survival_frames=20,
        offspring_possible_frames=25,
        unique_grid_cells=10,
    )
    base.update(updates)
    return base


def test_policy_weights_and_config():
    assert sum(sim.FITNESS_WEIGHTS.values()) == pytest.approx(1.0)
    assert sim.SimulationConfig().standard_suite_weight == pytest.approx(.70)
    with pytest.raises(ValueError):
        sim.SimulationConfig(standard_suite_weight=.8, challenge_suite_weight=.3)


def test_fitness_is_finite_bounded_and_late_birth_is_fair():
    cfg = sim.SimulationConfig(max_frames=200)
    components = sim.compute_fitness_components(metric(), cfg, 100, 1)
    assert all(0 <= value <= 1 for value in components.values())
    assert components["offspring_survival"] == pytest.approx(.8)


def test_better_outcomes_are_monotonic():
    cfg = sim.SimulationConfig(max_frames=200)
    low = sim.compute_fitness_components(metric(lineage_food=1, fire_contact_frames=5), cfg, 100, 1)
    high = sim.compute_fitness_components(metric(lineage_food=5, fire_contact_frames=1), cfg, 100, 1)
    assert high["food"] > low["food"]
    assert high["damage_avoidance"] > low["damage_avoidance"]


def test_suite_counts_do_not_change_weights():
    cfg = sim.SimulationConfig()
    brain = sim.Brain.random(cfg, sim.np.random.default_rng(1))
    def trial(profile, score):
        components = {name: score for name in sim.FITNESS_WEIGHTS}
        return sim.TrialSummary(1, 1, "max_frames", 1, 1, 1, score, components, {}, "0" * 64, profile)
    a = sim.Candidate(1, brain, trials=[trial("standard", .8), trial("water_fire_challenge", .2)])
    b = sim.Candidate(2, brain, trials=[trial("standard", .8)] * 5 + [trial("water_fire_challenge", .2)] * 3)
    assert a.selection_fitness == pytest.approx(b.selection_fitness)


def test_incremental_resource_index_matches_store_after_churn():
    cfg = sim.SimulationConfig(max_frames=10, initial_food=3, initial_water=3, initial_fire=1, food_capacity=5, water_capacity=5)
    brain = sim.Brain.random(cfg, sim.np.random.default_rng(2))
    world = sim.Simulation(cfg, brain, 3)
    for kind in world.resources:
        indexed = {obj.resource_id for bucket in world.resource_indexes[kind].cells.values() for obj in bucket}
        stored = {obj.resource_id for obj in world.resources[kind]}
        assert indexed == stored


def test_same_seed_same_final_hash():
    cfg = sim.SimulationConfig(max_frames=30, initial_food=10, initial_water=10, initial_fire=2, food_capacity=12, water_capacity=12)
    brain = sim.Brain.random(cfg, sim.np.random.default_rng(4))
    a = sim.Simulation(cfg, brain, 5).run()
    b = sim.Simulation(cfg, brain, 5).run()
    assert a.final_state_hash == b.final_state_hash
    assert a.fitness == b.fitness


def test_unsafe_experiment_id_rejected(tmp_path):
    with pytest.raises(ValueError):
        sim._artifact_paths(tmp_path, "../escape")
