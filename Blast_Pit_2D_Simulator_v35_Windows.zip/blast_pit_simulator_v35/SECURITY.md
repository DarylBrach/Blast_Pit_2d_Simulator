# Security

The simulator is offline: it contains no network client or subprocess execution. Spawned workers run only trial tasks and the parent process alone writes governed artifacts. NPZ checkpoints are loaded with pickle disabled and archive/member/metadata limits. Experiment IDs are restricted and resolved beneath the artifact root. Atomic temporary-file replacement is used for checkpoints and JSON evidence.

The approval JSON is a local authorization record, not a signature. The application is not an OS sandbox; run it using a dedicated account or VM if operating-system isolation is required. Do not run untrusted modified simulator source. Windows junction/reparse-point enforcement remains an operating-system deployment responsibility; keep the installation and artifact root owner-writable only.

Report suspected artifact tampering by retaining the complete experiment directory and comparing its SHA-256 manifest before further execution.
